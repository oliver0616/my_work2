# File:   plotter.py
# Author: Matthew Morgan
# Description:
# This program will take a series of CSV files with x/y coordinates, delimited
# by commas, and plot the coordinates to generate figures. These figures may be
# either shown to the user, or written to the disk
#
# Installation Requirements:
# - matplotlib
#
# Execution Examples:
# Show + Save: python plotter.py -infile ./csvdir/ -outfile ./outdir/
# Save:        python plotter.py -infile ./csvdir/ -outfile ./outdir/ -noshow
# Show:        python plotter.py -infile ./csvdir/
# Neither:     python plotter.py -infile ./csvdir/ -noshow

# Import statements
import matplotlib.pyplot as plt
import csv
import sys
import glob
import os
import ntpath

# Error values
global ERR_NONE, ERR_CMD_UNKNOWN, ERR_LABEL_AXIS, ERR_OS_ERROR, ERR_FILE_MISMATCH, ERR_FILE_NOEXIST
ERR_NONE = 0
ERR_CMD_UNKNOWN = 1
ERR_LABEL_AXIS = 2
ERR_OS_ERROR = 3
ERR_FILE_MISMATCH = 4
ERR_FILE_NOEXIST = 5

def __main__(argc, args):
  # files stores [in-is-dir, out-is-dir, in-loc, out-loc]
  # delim is the delimiter of the CSV files
  # noShow dictates if figures are shown after generation
  # label stores [title, xaxis, yaxis]
  # xPoints and yPoints store coordinate data for figures
  global files, delim, noShow
  global label, xPoints, yPoints
  noShow = False
  delim = ','
  label = ["", "" , ""]
  files = [False, False, [""], ""]

  argumentCheck(argc, args)
  if files[0]: files[2] = glob.glob(files[2][0]+"*.csv")

  if noShow: print("SYS: Not showing figures!")
  print("Generating Figures...")

  for i in range(0, len(files[2])):
    # Reset coordinate point variables and determine filename
    xPoints, yPoints = [], []
    if files[0]:
      fname = ntpath.basename(files[2][i])
      fname = fname[0:len(fname)-4]
      print("  File: '"+files[2][i]+"' --> '"+fname+".png'")

    # With the file, read in coordinate data
    # Blank lines and those without integers are skipped
    with open(files[2][i]) as f:
      plots = csv.reader(f, delimiter=delim)
      for col in plots:
        if col == []: continue
        try: xPoints.append(int(col[0]))
        except ValueError: continue
        yPoints.append(int(col[1]))

    # Set up plot, and then show it, saving it as a figure
    # Clear the plot's properties afterward
    plt.plot(xPoints, yPoints, label=label[0])
    plt.xlabel(label[1])
    plt.ylabel(label[2])
    if not files[3]=="":
      if files[0]:
        plt.savefig(files[3]+"/figure-"+fname+".png")
      else:
        plt.savefig(files[3])
    if not noShow: plt.show()
    plt.clf()
    plt.cla()
    plt.close()

""" Runs a check on the parameters passed to the program, detecting if an
    invalid option is toggled, or if the arguments are otherwise invalid. """
def argumentCheck(argc, args):
  error = ERR_NONE
  offset = 0

  for i in range(1, argc):
    if offset:
      offset -= 1
      continue
    elif error > ERR_NONE: break

    # label checks for labels for the title and graph axis (x and y)
    if args[i] == "-label":
      if i+1 >= argc: error = ERR_LABEL_AXIS
      else:
        label[0] = args[i+1]
        if i+2 < argc and not args[i+2][0]=='-': label[1] = args[i+2]
        if i+3 < argc and not args[i+3][0]=='-': label[2] = args[i+3]
        for k in range(0, 3): offset += (not label[k]=="")
    # infile checks the location of where the user wants to load data from
    elif args[i] == "-infile":
      offset = 1
      files[2][0] = args[i+1]
      files[0] = os.path.isdir(files[2][0])
      if not os.path.exists(files[2][0]): error = ERR_FILE_NOEXIST
    # outfile checks the location of where the user wants to store
    # figures after their generation
    elif args[i] == "-outfile":
      offset = 1
      files[3] = args[i+1]
      files[1] = files[3][len(files[3])-1] == '/'
      if files[1]:
        try:
          if not os.path.exists(files[3]): os.makedirs(os.path.dirname(files[3]))
        except OSError:
          error = ERR_OS_ERROR
    # noShow mandates that figures NOT be shown to the user
    elif args[i] == "-noshow":
      global noShow
      noShow = True
    # Parameter is unknown, and thus an error is flagged
    else: error = ERR_CMD_UNKNOWN
  
  # Extraneous error checks
  if (not files[0] and files[1]) or (files[0] and not files[1]): error = ERR_FILE_MISMATCH
  
  if error > ERR_NONE: sysError(error)
    
""" Prints error text based on the error code that was found during argument
    checking for the program. The usage of the program is then printed, and
    execution terminated. """
def sysError(code):
  txt = ""

  # Set error text
  if code == ERR_CMD_UNKNOWN:
    txt = "Unknown parameter passed to program"
  elif code == ERR_LABEL_AXIS:
    txt = "Insufficient number of labels provided"
  elif code == ERR_OS_ERROR:
    txt = "An OSError occured during path checking for file input"
  elif code == ERR_FILE_MISMATCH:
    txt = "Either input or output is a single file, but the other is a dir"
  elif code == ERR_FILE_NOEXIST:
    txt = "The input file specified doesn't exist"
  
  # Print error text and usage information
  print("ERR: " + txt)
  print("usage: python plotter.py [options]")
  print("Options:")
  print("  -label t x y  Specify the labels for the title, x and y axis")
  print("  -outfile loc  Specify the location to store figures")
  print("  -infile loc   Specify the location to load plot information")
  print("  -noshow       Specify to not show figures upon generation")
  exit(1)

__main__(len(sys.argv), sys.argv)