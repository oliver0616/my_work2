clear

# Set classpath variables
export LUCENEJAR=Lucene.jar
export CLASSPATH=".:lucene-core-7.3.0.jar:lucene-queryparser-7.3.0.jar"

mkdir "out" "prog"

# Compile the program and then run it
javac -d ./out/ -cp $CLASSPATH Lucene.java Heaper.java
jar cfmv $LUCENEJAR manifest.txt -C ./out/ .
rm -d -f -r -v "out"
java -jar Lucene.jar ../../../Corpa/gutenberg -index ./prog/index -trace -heap ./prog/heap

# OPTIONS for running
# ../../../Corpa/gutenberg -index ./prog/index				## Used for the gutenberg corpus
# ../../../Corpa/mnm-mini-corpa -index ./prog/index-mini	## Used for the mini corpa
# ../../../Corpa/cran/docs -index ./prog/index-cran         ## Used for the cranfield collection

echo
echo Program completed